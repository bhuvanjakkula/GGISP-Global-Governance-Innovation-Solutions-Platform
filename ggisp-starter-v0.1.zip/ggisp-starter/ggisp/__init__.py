"""GGISP local research prototype."""
